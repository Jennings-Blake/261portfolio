console.log (pi = 3.142);

console.log(function strictly(){
    "use strict";
   });

   if (window.unicorn) {
    unicorn();
   }
   
   